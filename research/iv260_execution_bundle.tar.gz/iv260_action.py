"""IV260: certified original-operator action on IV259 four band functions.
Run from /tmp with pinned iv254_intermediate.py and authenticated IV256 even factor.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='4';os.environ['OMP_NUM_THREADS']='4'
import numpy as np, math, json, hashlib, sys
from fractions import Fraction as F
from scipy.linalg import solve_triangular
import iv254_intermediate as c
K=1536; J=28672; L=2*J; Q=1<<27; H=1<<24; V=Q*H; S=c.S; T=c.T
c.J=L
assert c.M==512
# Literal scalar nodes, all intervals inherited from IV254.
dd,pd,gg=c.nodes();jj=np.arange(512,L,2,dtype=np.int64);d=dd[::2];p=pd[::2];g=gg[::2];n=(J-512)//2
# For all j>=512: A'_j=j(2+2 b_j/alpha)+1/(2alpha^2)+eps,
# |eps|<=16/j+.001 (IV259 proof also valid at 512).
# IV254 center d/DS and ia/IS have errors <=2/DS and <=2/IS.
# |b|<13, 1/alpha<4/3; product error <= 2*((4/3)*2/DS+(13+2/DS)*2/IS) < 1e-7.
assert 2*(F(4,3)*F(2,c.DS)+(13+F(2,c.DS))*F(2,c.IS))<F(1,10**7)
assert (F(4,3)+F(2,c.IS))*F(2,c.IS)<F(1,10**8)
ac=np.array([(2*int(j)*Q+ (2*int(j)*int(x)*c.ia*Q)//(c.DS*c.IS)+(c.ia*c.ia*Q)//(2*c.IS*c.IS)) for j,x in zip(jj,d)],dtype=np.int64)
# Absolute A' center radius <= 16/j+.001 + j*1e-7+1e-8+2/Q.
# Ceil Q times this quantity by exact rational arithmetic.
ar=np.array([c.ce((F(16,int(j))+F(1,1000)+F(int(j),10**7)+F(1,10**8)+F(2,Q)).numerator*Q,(F(16,int(j))+F(1,1000)+F(int(j),10**7)+F(1,10**8)+F(2,Q)).denominator) for j in jj],dtype=np.int64)
# IV254 lower g_j includes -2^-20; log recurrence error < 1e-12 for j<L.
# Use diagonal center 2(g-p), with original normalized boundary+pole magnitude <=2/j+43/j^2 (IV254/249).
assert 2*(L-512)*(F(1,S)*6+F(2,11*1025**11)*F(1025**2,1025**2-1))<F(1,10**12)
# Check log64 anchor width and include floor to T, prime diagonal error 2/T.
assert F(c.log(64)[1]-6*c.L2[0],S)<F(1,10**12)
dc=np.array([2*(int(x)-int(y))*Q//T for x,y in zip(g,p)],dtype=np.int64)
dr=np.array([c.ce((F(32,3*int(j))+F(4,9*int(j)**2)+F(2,1<<20)+F(2,10**12)+F(4,int(j))+F(86,int(j)**2)+F(8,T)+F(1,Q)).numerator*Q,(F(32,3*int(j))+F(4,9*int(j)**2)+F(2,1<<20)+F(2,10**12)+F(4,int(j))+F(86,int(j)**2)+F(8,T)+F(1,Q)).denominator) for j in jj],dtype=np.int64)
# h_b coefficient centers floor H*(K/j)^2/32 on disjoint intervals.
weights=np.zeros((4,len(jj)),dtype=np.int64);mask=np.zeros_like(weights)
for b in range(4):
 lo=K*2**b;hi=K*2**(b+1) if b<3 else L
 sel=(jj>=lo)&(jj<hi);mask[b,sel]=1
 weights[b,sel]=H*K*K//(32*jj[sel]**2)
assert np.all(weights>=0)
# Exact row products; off-diagonal Q centers at Q, radius in same units.
# A'_j and A'_k interval error divided by exact signed denominator, plus one unit flooring.
cent=np.zeros((n,4),dtype=np.int64);rad=np.zeros((n,4),dtype=np.int64)
for i in range(0,n,128):
 sl=slice(i,min(i+128,n));den=jj[sl,None]**2-jj[None,:]**2;same=den==0;den[same]=1
 q=(ac[sl,None]-ac[None,:])//den
 ad=np.abs(den);e=(ar[sl,None]+ar[None,:]+ad-1)//ad+1
 ii,kk=np.where(same);q[ii,kk]=dc[np.arange(n)[sl][ii]];e[ii,kk]=dr[np.arange(n)[sl][ii]]
 # coeff exact in [weights/H,(weights+mask)/H]. Error in action scaled V:
 # e*(weights+mask)+abs(q)*mask.
 ma=int(np.max(np.abs(q)));me=int(np.max(e));sw=int(np.max(np.sum(weights+mask,axis=1)));sm=int(np.max(np.sum(mask,axis=1)))
 assert (ma+me)*sw+ma*sm<2**62
 cent[sl]=q@weights.T;rad[sl]=e@(weights+mask).T+np.abs(q)@mask.T
# For j<J, omitted k>=L all belong to h3. |A'_j|<=41j, |A'_k|<=41k => |Q_jk|<=82/k.
# Unnormalized action row tail absolute <= (82 K^2/32)*(L^-3+1/(4 L^2)).
rem=F(82*K*K,32)*(F(1,L**3)+F(1,4*L**2));erem=c.ce(rem.numerator*V,rem.denominator);rad[:,3]+=erem
assert np.all(rad>=0)
# Integer row interval norms and 4x4 Gram of prefix action. Exact Python ints.
def gram(cen,rr):
 out=[]
 for i in range(4):
  row=[]
  for j in range(4):
   mid=err=0
   for a,b,x,y in zip(cen[:,i],cen[:,j],rr[:,i],rr[:,j]):
    a,b,x,y=map(int,(a,b,x,y));mid+=a*b;err+=abs(a)*y+abs(b)*x+x*y
   row.append([str(mid-err),str(mid+err)])
  out.append(row)
 return out
prefix=(K-512)//2
out={'scale':str(V),'prefix_rows':prefix,'intermediate_rows':n,'source_end_exclusive':L,'tail_row_remainder_scaled':str(erem),'prefix_gram_interval_scaled_squared':gram(cent[:prefix],rad[:prefix]),'intermediate_gram_interval_scaled_squared':gram(cent,rad),'column_max_radius_scaled':[str(int(x)) for x in rad.max(axis=0)],'prefix_column_max_radius_scaled':[str(int(x)) for x in rad[:prefix].max(axis=0)]}
# Actual four-channel energy Gram from action on I, plus omitted rows j>=J (h3 only).
# Instead of claiming a computed full Gram, bound missing diagonal h3 energy and mixed terms via Q_H positivity and C_H<=gamma+32.
# Compute factorized majorant on intermediate projection of each action: use L0=Kfac Kfac^T/T+1/125 I.
# L0 <= IV259 L_I; actual factor must match immutable receipt hash.
def sha(path):
 z=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):z.update(b)
 return z.hexdigest()
path='/tmp/iv256_0_factor.npy';expected='aff3ad547832c8985e975577e70fbc114346b53c60c469bdabaa71751826a254'
assert sha(path)==expected
fac=np.load(path,mmap_mode='r');assert fac.shape==(n,n) and fac.dtype==np.int32
# Instead of a dense shifted solve, use triangular factor proposal L0^-1 r approximately via K K^T.
# Exact residual of L0 applied to rational candidate, matrix products done in bounded blocks.
# Work in unnormalized action units; physical residual divides by sqrt(2), so inverse energies divide by 2.
# Reconstruct double factor only for proposal. Memory ~1.6GB.
Fmat=np.array(fac,dtype=np.float64,order='F')/(1<<23)
# CG with factor as preconditioner for shifted system, 4 RHS, fixed bounded iterations.
from scipy.sparse.linalg import cg,LinearOperator
op=LinearOperator((n,n),matvec=lambda x:Fmat@(Fmat.T@x)+x/125,dtype=np.float64)
pre=LinearOperator((n,n),matvec=lambda x:solve_triangular(Fmat.T,solve_triangular(Fmat,x,lower=True,check_finite=False),lower=False,check_finite=False),dtype=np.float64)
# Quantize center rhs to physical unnormalized action units and proposals X at 2^30.
Xs=1<<30; X=np.empty((n,4),dtype=np.int64);infos=[]
for b in range(4):
 x,info=cg(op,cent[:,b].astype(float)/V,M=pre,rtol=1e-11,maxiter=40);assert np.isfinite(x).all() and np.max(np.abs(x))*Xs<2**52
 X[:,b]=np.rint(x*Xs).astype(np.int64);infos.append(int(info))
del Fmat
# Exact products K^T X and K (K^T X) in Python/BLAS integer arithmetic.
# First product via int64 blocks, check absolute sum with Cauchy or l1 bounds; second may exceed int64.
# Use rounded intermediate K^T X / FS (FS=2^23) at scale Xs, charge row rounding on second product.
FS=1<<23;U0=np.zeros((n,4),dtype=np.int64)
maxx=int(np.max(np.abs(X)));sumx=int(np.max(np.sum(np.abs(X),axis=0)))
for k in range(0,n,128):
 sl=slice(k,min(k+128,n));b=np.asarray(fac[:,sl],dtype=np.int64);assert int(np.max(np.abs(b)))*sumx<2**62
 U0[sl]=(b.T@X)//FS
sumu=int(np.max(np.sum(np.abs(U0),axis=0)));prod=np.zeros((n,4),dtype=np.int64);perr=np.zeros(n,dtype=np.int64)
for k in range(0,n,128):
 sl=slice(k,min(k+128,n));b=np.asarray(fac[sl,:],dtype=np.int64);mx=int(np.max(np.abs(b)));assert mx*sumu<2**62
 prod[sl]=b@U0;perr[sl]=np.sum(np.abs(b),axis=1,dtype=np.int64)
# residual of L0 x (at denominator 125 FS Xs V), exact center and radius.
D=125*FS*Xs*V
Rc=[];Re=[];energy=[]
for b in range(4):
 rc=[];re=[]
 for i in range(n):
  rc.append(int(cent[i,b])*(125*FS*Xs)-V*(125*int(prod[i,b])+FS*int(X[i,b])))
  re.append(int(rad[i,b])*(125*FS*Xs)+V*125*int(perr[i]))
 Rc.append(rc);Re.append(re)
# Actual projection energy interval via variational identity e=2r.x-x.Lx+res.L^-1 res.
# Matrix symmetric interval using exact bilinear form: Q0_ij = x_i.r_j+x_j.r_i-x_i.Lx_j.
# Lx_j center=(125 prod_j+FS X_j)/(125 FS Xs); error<=perr/(FS Xs).
# A simpler common scale: denominator 125 FS Xs^2 V.
ED=125*FS*Xs*Xs*V;energyMid=[];energyErr=[];resNorm=[]
for b in range(4):
 resNorm.append(sum((abs(x)+y)**2 for x,y in zip(Rc[b],Re[b])))
for i in range(4):
 em=[];ee=[]
 for j in range(4):
  mid=err=0
  for k in range(n):
   xi,xj=int(X[k,i]),int(X[k,j]);ci,cj=int(cent[k,i]),int(cent[k,j]);ri,rj=int(rad[k,i]),int(rad[k,j]);lj=125*int(prod[k,j])+FS*xj
   mid+=125*FS*Xs*(xi*cj+xj*ci)-V*xi*lj
   err+=125*FS*Xs*(abs(xi)*rj+abs(xj)*ri)+V*125*abs(xi)*int(perr[k])
  em.append(str(mid));ee.append(str(err))
 energyMid.append(em);energyErr.append(ee)
# Upper inverse Gram of projection: center+entry error row norm+125 residual trace I.
# Symmetrize by lower triangle; no use of floating solve accuracy.
for i in range(4):
 for j in range(i):energyMid[j][i]=energyMid[i][j];energyErr[j][i]=energyErr[i][j]
loss=F(max(sum(map(int,row)) for row in energyErr),ED)+125*F(sum(resNorm),D*D)
# Upper inverse Gram in unnormalized residual coordinates; divide by 2 for physical energy.
out.update({'factor_sha256':expected,'factor_uses_shift':'1/125','proposal_cg_info':infos,'inverse_variational_center_denominator':str(ED),'inverse_variational_center':energyMid,'inverse_variational_radius':energyErr,'inverse_residual_denominator':str(D),'inverse_residual_column_square_upper_numerators':[str(x) for x in resNorm],'inverse_upper_uniform_loss':str(loss),'scope':'projection of C_H h_b onto IV256 intermediate block only; full mixed r_T term not evaluated'})
open('/tmp/iv260_action.json','w').write(json.dumps(out,indent=2)+'\n')
np.savez('/tmp/iv260_action_checkpoint.npz',center=cent,radius=rad,proposal=X)
print(json.dumps(out,indent=2),flush=True)
