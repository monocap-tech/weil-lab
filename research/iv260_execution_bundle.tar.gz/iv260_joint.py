"""IV260: refine analytic source tail, orthogonalize correction against prefix,
and evaluate the IV256 factor inverse on the projected channel action.
Requires executed iv260_action.py checkpoint; no new Galerkin support cutoff.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='4';os.environ['OMP_NUM_THREADS']='4'
import numpy as np, math,json,hashlib
from fractions import Fraction as F
from scipy.linalg import solve,solve_triangular
from scipy.sparse.linalg import cg,LinearOperator
import iv254_intermediate as c
K=1536;J=28672;L=2*J;Q=1<<27;H=1<<24;V=Q*H;S=c.S;T=c.T;Xs=1<<30;FS=1<<23;U=10**30
Ps=1<<24
n=(J-512)//2;prefix=(K-512)//2;c.J=J

def sha(path):
 z=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):z.update(b)
 return z.hexdigest()
checkpoint='/tmp/iv260_action_checkpoint.npz';ch='458fb881991de1a598322d4842d483c993c20df7d964feb8913cc33c8069b7ee'
assert sha(checkpoint)==ch
initial=json.load(open('/tmp/iv260_action.json'));D0=np.load(checkpoint);cent=D0['center'];rad=D0['radius'];oldX=D0['proposal'];assert cent.shape==rad.shape==(n,4)
# All scalar bounds and normalizations same as the executed first stage.
dd,pd,gg=c.nodes();jj=np.arange(512,J,2,dtype=np.int64);d=dd[::2];p=pd[::2];g=gg[::2]
ac=np.array([(2*int(j)*Q+(2*int(j)*int(x)*c.ia*Q)//(c.DS*c.IS)+(c.ia*c.ia*Q)//(2*c.IS*c.IS)) for j,x in zip(jj,d)],dtype=np.int64)
def cq(x,s):return c.ce(x.numerator*s,x.denominator)
ar=np.array([cq(F(16,int(j))+F(1,1000)+F(int(j),10**7)+F(1,10**8)+F(2,Q),Q) for j in jj],dtype=np.int64)
dc=np.array([2*(int(x)-int(y))*Q//T for x,y in zip(g,p)],dtype=np.int64)
dr=np.array([cq(F(32,3*int(j))+F(4,9*int(j)**2)+F(2,1<<20)+F(2,10**12)+F(4,int(j))+F(86,int(j)**2)+F(8,T)+F(1,Q),Q) for j in jj],dtype=np.int64)
# The previously omitted k>=L source of h3 is now included analytically.
# S_p=sum_{even k>=L}(L/k)^p = L/[2(p-1)]+1/2 +/- p/(4L).
# The step-two trapezoid error follows by integrating |f''|, see report.
# Oscillatory sine-weighted sum is bounded by B_osc<52 (IV259).
terms=24;sp=[];fp=[];lam=c.ra(c.inv,2,1);a0=c.ra(c.mu(c.inv,c.inv),1,2)
assert lam[1]<3*S and a0[1]<S
for m in range(terms):
 def sm(p):
  v=F(L,2*(p-1))+F(1,2);r=F(p,4*L)
  return c.I((v-r).numerator,(v-r).denominator)[0],c.I((v+r).numerator,(v+r).denominator)[1]
 s3=sm(3+2*m);s4=sm(4+2*m);err=c.ra(s4,16*1000+L,1000*L)[1]
 fp.append(c.ad(c.ra(s3,2,1),c.mu(lam,(-52*S,52*S))))
 sp.append(s4)
 # eps_k bounded by 16/L+1/1000, times positive S4 sum.
 if m==0:ep=[]
 ep.append((-err,err))
oldrem=int(initial['tail_row_remainder_scaled']);geomrem=cq(F(82*K*K,32)*(F(1,L**3)+F(1,4*L**2))/4**terms,V)
rad[:,3]-=oldrem;assert np.min(rad[:,3])>=0
new_tail_radius=0;new_tail_center=0
for i,j0 in enumerate(jj):
 j=int(j0);u=c.I(j*j,L*L);a=(c.I(int(ac[i])-int(ar[i]),Q)[0],c.I(int(ac[i])+int(ar[i]),Q)[1]);p3=p4=pe=c.I(0)
 for m in range(terms-1,-1,-1):
  p3=c.ad(fp[m],c.mu(u,p3));p4=c.ad(sp[m],c.mu(u,p4));pe=c.ad(ep[m],c.mu(u,pe))
 y=c.ad(c.ra(p3,K*K,32*L**3),c.ra(c.ad(c.mu(c.su(a0,a),p4),pe),K*K,32*L**4))
 lo=y[0]*V//S-geomrem;hi=c.ce(y[1]*V,S)+geomrem;mid=(lo+hi)//2;err=max(mid-lo,hi-mid)
 cent[i,3]+=mid;rad[i,3]+=err;new_tail_radius=max(new_tail_radius,err);new_tail_center=max(new_tail_center,abs(mid))
# Original high action on prefix-correction functions, preserving actual Q.
def entries(sl,kk):
 den=jj[sl,None]**2-jj[None,kk]**2;same=den==0;den[same]=1
 m=(ac[sl,None]-ac[None,kk])//den;ad=np.abs(den);r=(ar[sl,None]+ar[None,kk]+ad-1)//ad+1
 ii,jj0=np.where(same);inds=np.arange(n)[sl][ii];m[ii,jj0]=dc[inds];r[ii,jj0]=dr[inds];return m,r
P0=slice(0,prefix);hc,hr=entries(P0,P0)
# Numerical proposal only; exact interval residual below.
x=solve(hc.astype(float)/Q,cent[:prefix].astype(float)/V,assume_a='pos');assert np.isfinite(x).all() and np.max(np.abs(x))*Ps<2**52
xp=np.rint(x*Ps).astype(np.int64);xabs=np.abs(xp);sumx=int(np.max(np.sum(xabs,axis=0)))
print("prefix projection max and sum scaled",int(np.max(np.abs(xp))),sumx,flush=True)
cp=cent.copy();rp=rad.copy()
# For h_b^perp=h_b-sum xp_{kb}/Xs cos_k, subtract actual original action of prefix projection.
# Convert exact integer center product to units V with directed radius, including rounding.
for i in range(0,n,128):
 sl=slice(i,min(i+128,n));a,b=entries(sl,P0);assert (int(np.max(np.abs(a)))+int(np.max(b)))*sumx<2**62
 prod=a@xp;er=b@xabs
 # Q*Xs = V * (Xs/H). exact because powers of two.
 assert Ps%H==0;ratio=Ps//H
 cp[sl]-=prod//ratio;rp[sl]+=(er+ratio-1)//ratio+1
# Exact Gram intervals at scale V^2 (unnormalized row norms).
def gram(cc,rr):
 out=[]
 for i in range(4):
  row=[]
  for j in range(4):
   mid=err=0
   for a,b,x,y in zip(cc[:,i],cc[:,j],rr[:,i],rr[:,j]):
    a,b,x,y=map(int,(a,b,x,y));mid+=a*b;err+=abs(a)*y+abs(b)*x+x*y
   row.append([str(mid-err),str(mid+err)])
  out.append(row)
 return out
# Exact energy Gram for the actual full analytic channels.
# Rows b<3 are entirely inside I and include full source h_c. For G33 alone,
# missing <h3_tail,C h3> bounded by Cauchy in positive high form.
# For j>=B0=12288 or J, gamma+32 <= 41+j/B0, because log(B0/8)<9.
assert c.log(J,8)[1]<9*S

def diag_upper(B0):
 return F(2*K**4,1024)*(41*(F(1,B0**4)+F(1,6*B0**3))+F(1,B0)*(F(1,B0**3)+F(1,4*B0**2)))
bound=diag_upper(8*K)*diag_upper(J);tailenergy=math.isqrt(cq(bound,U*U))+1
G=[]
for b in range(4):
 row=[]
 for a in range(4):
  if a<b:row.append(G[a][b]);continue
  lower=upper=0
  for i in range(n):
   j=int(jj[i]);lo=K*(1<<b);hi=lo*2 if b<3 else J
   if not lo<=j<hi:continue
   w=H*K*K//(32*j*j);cc=int(cent[i,a]);rr=int(rad[i,a]);p=[w*(cc-rr),w*(cc+rr),(w+1)*(cc-rr),(w+1)*(cc+rr)];lower+=min(p);upper+=max(p)
  lo=lower*U//(H*V);hi=c.ce(upper*U,H*V)
  if b==3 and a==3:lo-=tailenergy;hi+=tailenergy
  row.append([lo,hi])
 G.append(row)
# G_perp=G-X_b^T t_a-X_a^T (t_b-H X_b) in exact original Q.
Gp=[]
for b in range(4):
 row=[]
 for a in range(4):
  if a<b:row.append(Gp[a][b]);continue
  mid=err=0
  for i in range(prefix):
   xb,xa=int(xp[i,b]),int(xp[i,a]);mid+=xb*int(cent[i,a])+xa*int(cp[i,b]);err+=abs(xb)*int(rad[i,a])+abs(xa)*int(rp[i,b])
  lo=(mid-err)*U//(Ps*V);hi=c.ce((mid+err)*U,Ps*V)
  row.append([G[b][a][0]-hi,G[b][a][1]-lo])
 Gp.append(row)
# A rigorous 4x4 upper matrix using interval midpoint + rowwise absolute error.
Gmid=[[(x[0]+x[1])//2 for x in row] for row in Gp];Gerr=[[max(m-x[0],x[1]-m) for m,x in zip(row,iv)] for row,iv in zip(Gmid,Gp)]
Dupper=[row.copy() for row in Gmid]
for i in range(4):Dupper[i][i]+=sum(Gerr[i])
# Exact positive pivots for this upper matrix, no floating sign decisions.
a=[[F(x,U) for x in row] for row in Dupper];piv=[]
for i in range(4):
 d=a[i][i];assert d>0;piv.append(str(d))
 for j in range(i+1,4):
  for k in range(i+1,4):a[j][k]-=a[j][i]*a[i][k]/d
# Prefix residual correlation error: ||old residual prefix||_2 <= sqrt(pre_trace),
# x_b is rational; upper |<old residual,x_b>| bound at U via exact sqrt.
# Use IV258 certified old squared unnormalized trace <4.37e-18.
xb2=[sum(int(x)**2 for x in xp[:,b]) for b in range(4)]
correrr=[math.isqrt(cq(F(437,10**20)*F(v,Ps*Ps),U*U))+1 for v in xb2]
# Exact projected factor inverse for orthogonalized channel action cp/rp.
path='/tmp/iv256_0_factor.npy';expected='aff3ad547832c8985e975577e70fbc114346b53c60c469bdabaa71751826a254';assert sha(path)==expected
fac=np.load(path,mmap_mode='r');assert fac.shape==(n,n) and fac.dtype==np.int32
Fmat=np.array(fac,dtype=np.float64,order='F');Fmat/=FS
op=LinearOperator((n,n),matvec=lambda x:Fmat@(Fmat.T@x)+x/125,dtype=np.float64)
pre=LinearOperator((n,n),matvec=lambda x:solve_triangular(Fmat.T,solve_triangular(Fmat,x,lower=True,check_finite=False),lower=False,check_finite=False),dtype=np.float64)
X=np.empty((n,4),dtype=np.int64);infos=[]
for b in range(4):
 x,info=cg(op,cp[:,b].astype(float)/V,M=pre,rtol=1e-11,maxiter=40);assert np.isfinite(x).all() and np.max(np.abs(x))*Xs<2**52
 X[:,b]=np.rint(x*Xs).astype(np.int64);infos.append(int(info))
del Fmat
# Replay exact integer inverse-residual verifier from the authenticated first-stage source.
# Same definitions, but cp/rp instead of cent/rad. All range guards rerun.
srcpath='/tmp/iv260_action.py';src=open(srcpath).read();assert hashlib.sha1(('blob '+str(len(src.encode()))+'\0').encode()+src.encode()).hexdigest()=='66f28ee547f9995abb0b529f59c97f51b20492da'
start=src.index('# Exact products K^T X');end=src.index('out.update',start);block=src[start:end]
# 'cent' and 'rad' temporarily point to the post-orthogonalization action.
origc,origr=cent,rad;cent,rad=cp,rp;exec(block);cent,rad=origc,origr
out={'action_checkpoint_sha256':ch,'scale':str(V),'energy_scale':str(U),'prefix_rows':prefix,'intermediate_rows':n,'source_end_exclusive':L,'refined_tail_terms':terms,'refined_tail_max_center_scaled':str(new_tail_center),'refined_tail_max_radius_scaled':str(new_tail_radius),'original_prefix_gram_interval_scaled_squared':gram(cent[:prefix],rad[:prefix]),'orthogonalized_prefix_gram_interval_scaled_squared':gram(cp[:prefix],rp[:prefix]),'orthogonalized_intermediate_gram_interval_scaled_squared':gram(cp,rp),'full_analytic_energy_gram_interval_scaled':[[list(map(str,x)) for x in row] for row in G],'orthogonalized_energy_gram_interval_scaled':[[list(map(str,x)) for x in row] for row in Gp],'orthogonalized_energy_upper_scaled':[list(map(str,row)) for row in Dupper],'upper_gram_exact_pivots':piv,'last_energy_omission_radius_scaled':str(tailenergy),'prefix_projection_coeff_scale':str(Ps),'prefix_projection_column_square_numerators':list(map(str,xb2)),'correlation_extra_error_scaled':list(map(str,correrr)),'factor_sha256':expected,'factor_uses_shift':'1/125','proposal_cg_info':infos,'inverse_variational_center_denominator':str(ED),'inverse_variational_center':energyMid,'inverse_variational_radius':energyErr,'inverse_residual_denominator':str(D),'inverse_residual_column_square_upper_numerators':[str(x) for x in resNorm],'inverse_upper_uniform_loss':str(loss),'scope':'full analytic energy upper matrix; factorized inverse on intermediate projection of orthogonalized channels only'}
open('/tmp/iv260_joint.json','w').write(json.dumps(out,indent=2)+'\n');np.savez('/tmp/iv260_joint_checkpoint.npz',prefix_projection=xp,center=cp,radius=rp,proposal=X)
print(json.dumps(out,indent=2),flush=True)
