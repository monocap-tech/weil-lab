"""Independent integer audit of IV265's final saved interval sign witness.
Does not independently rederive analytic/numerical input enclosures.
"""
import os,json,hashlib
from pathlib import Path
from fractions import Fraction as F
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
import numpy as np
P=Path(__file__).resolve().parent

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def main():
    r=json.loads((P/'iv265_sign.json').read_text());p=P/'iv265_sign.npz';assert sha(p)==r['sign_sha256']
    z=np.load(p);lo=z['lo'];hi=z['hi'];N=256;Q=1<<40;S=1<<48
    assert lo.shape==hi.shape==(N,N) and lo.dtype==hi.dtype==np.int64 and np.array_equal(lo,lo.T) and np.array_equal(hi,hi.T) and np.all(lo<=hi)
    margins=[]
    for i in range(N):
        margins.append(int(lo[i,i])-sum(max(abs(int(lo[i,j])),abs(int(hi[i,j]))) for j in range(N) if i!=j))
    gl=min(margins);assert list(map(str,margins))==r['gershgorin_row_numerators'] and str(gl)==r['gershgorin_min_numerator'] and 1000*gl>245*S
    def gram(V):
        assert V.shape==(N,N) and V.dtype==np.int64
        # Independently use Python integer inner products (not NumPy object matmul).
        rows=V.tolist();g=[[sum(x*y for x,y in zip(a,b)) for b in rows] for a in rows]
        return min(g[i][i]-sum(abs(g[i][j]) for j in range(N) if j!=i) for i in range(N))
    pm=gram(z['Vi']);wm=gram(z['Wi'].T);assert str(pm)==r['return_gram_margin_numerator'] and str(wm)==r['final_gram_margin_numerator'] and 100*min(pm,wm)>99*Q*Q
    auth=json.loads((P/'iv265_signed_auth.json').read_text());cert=json.loads((P/'iv265_finite_congruence.json').read_text());b=(P/'iv265_finite_congruence.json').read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==auth['finite_congruence_git_blob']=='97928a1ce7b3a7752301146b25c92f1b23b78861'
    W=[list(map(int,row)) for row in cert['basis']];o=[x['original_row'] for x in cert['details']];assert sorted(o)==list(range(N)) and all(W[i][o[i]]>0 and all(W[i][j]==0 for j in o[i+1:]) for i in range(N))
    out=dict(scope='independent exact final interval row and all three basis invertibility checks; analytic inputs inherited',sign_sha256=r['sign_sha256'],dimension=N,unordered_pairs=N*(N-1)//2,gram_denominator=str(Q*Q),return_gram_margin=str(pm),final_gram_margin=str(wm),original_pivoted_basis_verified=True,gershgorin_scale=S,min_numerator=str(gl),minimum_row=margins.index(gl),strict_gt='245/1000',certified=True)
    (P/'iv265_sign_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
