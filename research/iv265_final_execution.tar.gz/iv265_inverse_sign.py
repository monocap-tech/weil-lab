"""IV265 full odd lifted inverse and exact final sign test.
Conditional on IV251/256/262/263 analytic and IEEE/BLAS enclosure semantics.
No native Lean proof. No sign inferred from a floating eigenvalue.
"""
import os, math, json, time
from pathlib import Path
from fractions import Fraction as F
os.environ['OPENBLAS_NUM_THREADS']='4';os.environ['OMP_NUM_THREADS']='4'
import numpy as np
from scipy.linalg import solve_triangular
from iv265_residual import P, n,N,EPS,up,su,norm,mm,add,fracup,sha,gitsha

def main():
    start=time.time();r=json.loads((P/'iv265_residual.json').read_text());ir=json.loads((P/'iv265_receiver_inputs.json').read_text());plan=json.loads((P/'iv265_plan.json').read_text());assert sha(P/'iv265_residual.npz')==r['residual_sha256'] and sha(P/'iv265_receiver_inputs.npz')==ir['input_sha256']==r['sources']['receiver_inputs'] and sha(P/'iv265_basis_proposal.npz')==plan['proposal_sha256']==ir['rotation_source_sha256']
    f=Path('/tmp/iv256_1_factor.npy');assert sha(f)=='58ec1836be48df53cc52e3df32c4708fa1782184aa4531018432329476730c88'
    z=np.load(P/'iv265_residual.npz');D=z['D'];Dr=z['Dr'];G=z['G'];Gr=z['Gr'];y=z['y'];yr=z['yr'];assert y.shape==(n,N)
    fac=np.load(f,mmap_mode='r');assert fac.shape==(n,n) and fac.dtype==np.int32
    FM=np.empty((n,n),dtype=float,order='F')
    for k in range(0,n,128):FM[:,k:k+128]=fac[:,k:k+128]/float(1<<23)
    del fac
    # Certified exact IV256 row-square bound; Frobenius upper bound of FM.
    fb=fracup(F(n*710832192565515,1<<46));fn=float(up(math.sqrt(fb)))
    def pinv(v):return solve_triangular(FM.T,solve_triangular(FM,v,lower=True,check_finite=False),lower=False,check_finite=False)
    xx=pinv(y)
    for k in range(4):
        xx+=pinv(y-FM@(FM.T@xx)-xx/125)
        print('inverse refinement',k+1,time.time()-start,flush=True)
    Q=1<<40;assert np.all(np.isfinite(xx)) and np.max(np.abs(xx))*Q<2**52
    Zi=np.rint(xx*Q).astype(np.int64);xx=Zi.astype(float)/Q;v=FM.T@xx;u=FM@v;Lx=u+xx/125;del FM
    # Exact FM entries are binary64 dyadics. Each product has norm error
    # <= gamma ||FM||_F ||input||_2. Charge both products and addition.
    gam=(4*n+32)*EPS;xn=np.array([norm(xx[:,k]) for k in range(N)]);vn=np.array([norm(v[:,k]) for k in range(N)]);un=np.array([norm(u[:,k]) for k in range(N)])
    Lerr=up(fn*(gam*fn*xn)+gam*fn*vn+16*EPS*(un+xn/125))
    rv=y-Lx;res=up(np.array([norm(rv[:,k]) for k in range(N)])+Lerr+16*EPS*(np.array([norm(y[:,k]) for k in range(N)])+np.array([norm(Lx[:,k]) for k in range(N)])))
    ivloss=float(up(125*su(res*res)));A,Ar=mm(y.T,np.zeros_like(y.T),xx,np.zeros_like(xx));H,Hr=mm(xx.T,np.zeros_like(xx.T),Lx,np.zeros_like(Lx));Hr=up(Hr+xn[:,None]*Lerr[None,:]);iv,ivr=add(A,Ar,A.T,Ar.T);iv,ivr=add(iv,ivr,-H,Hr)
    # Physical inverse factor 1/2. Separate Young parameters late 1/10,
    # mixed 32, as in IV263, use inherited L0 shift 1/125 (not .0082).
    pen,penr=add(G/4,up(Gr/4),16.5*iv,up(16.5*ivr+16*EPS*np.abs(16.5*iv)))
    loss=float(up((5*r['nearF']**2+5*r['aeF']**2+r['farF']**2/2.9+33*ivloss+(1+1/32)*125*r['mixed_error']**2)/2))
    print('lifted inverse',time.time()-start,'loss',loss,'inverse residual loss',ivloss,flush=True)
    # Return to original W coordinates using P=V^T, not an approximate inverse.
    # Exact invertibility of V and P from integer Gram, K=V P near identity.
    b=np.load(P/'iv265_basis_proposal.npz');Vi=b['Vi'];VS=int(b['VS']);assert VS==Q and Vi.shape==(N,N) and np.max(np.abs(Vi))<=Q
    def gram_margin(Vi):
        V=Vi.astype(object);g=V.T@V;return min(int(g[i,i])-sum(abs(int(g[i,j])) for j in range(N) if i!=j) for i in range(N))
    pm=gram_margin(Vi.T);assert 100*pm>99*Q*Q
    V=Vi.astype(float)/Q;Pt=V.T.copy();Pz=np.zeros_like(Pt);K,Kr=mm(V,np.zeros_like(V),Pt,Pz)
    u=np.load(P/'iv265_receiver_inputs.npz');F1=u['F1_W'];F1r=u['F1r_W'];assert F1.shape==(N,N)
    def cong(A,Ar,M,Mr):
        c,cr=mm(M.T,Mr.T,A,Ar);return mm(c,cr,M,Mr)
    c,cr=cong(F1,F1r,K,Kr);d,dr=cong(D,Dr,Pt,Pz);c,cr=add(c,cr,d,dr);p,pr=cong(pen,penr,Pt,Pz);c,cr=add(c,cr,-p,pr);g,gr=mm(Pt.T,Pz.T,Pt,Pz);c,cr=add(c,cr,-loss*g,up(loss*gr+16*EPS*np.abs(loss*g)))
    cs=(c+c.T)/2;rs=up((cr+cr.T)/2+16*EPS*(np.abs(c)+np.abs(c.T)));dl=su(rs,axis=1);T=cs-np.diag(dl);Tr=up(16*EPS*(np.abs(cs)+np.diag(dl)))
    # The lower form T +/- Tr dominates by exact directional row allowances.
    ev,W=np.linalg.eigh(T);Wi=np.rint(W*Q).astype(np.int64);wm=gram_margin(Wi);assert 100*wm>99*Q*Q;W=Wi.astype(float)/Q
    h,hr=cong(T,Tr,W,np.zeros_like(W));hr=up(hr+16*EPS*np.abs(h));Z=1<<48
    lo=np.floor((h-hr)*Z);hi=np.ceil((h+hr)*Z);assert np.max(np.abs(lo))<2**52 and np.max(np.abs(hi))<2**52
    lo=lo.astype(np.int64)-2;hi=hi.astype(np.int64)+2
    # Intersect transposed intervals of the true symmetric lower form.
    lo=np.maximum(lo,lo.T);hi=np.minimum(hi,hi.T);assert np.all(lo<=hi)
    margins=[int(lo[i,i])-sum(max(abs(int(lo[i,j])),abs(int(hi[i,j]))) for j in range(N) if i!=j) for i in range(N)];gl=min(margins)
    out=P/'iv265_sign.npz';np.savez(out,Zi=Zi,Vi=Vi,Wi=Wi,lo=lo,hi=hi,iv=iv,ivr=ivr,loss=loss,Dloss=dl)
    rec=dict(scope='actual odd full 256-dimensional Schur lower form; conditional on stated numerical enclosures; no native proof or Phase IV adoption',source_git_blob=gitsha(Path(__file__)),residual_sha256=r['residual_sha256'],receiver_sha256=ir['input_sha256'],rotation_sha256=plan['proposal_sha256'],factor_sha256=sha(f),inverse_shift='1/125',factor_frobenius_upper=fn,inverse_center_residual_fro_upper=norm(res),inverse_center_residual_penalty=ivloss,young_late='1/10',young_mixed='32',uniform_loss=loss,maximum_directional_radius=float(max(dl)),lower_center_min_diagnostic=float(ev[0]),return_gram_margin_numerator=str(pm),final_gram_margin_numerator=str(wm),gram_denominator=str(Q*Q),gershgorin_scale=Z,gershgorin_min_numerator=str(gl),gershgorin_row_numerators=list(map(str,margins)),strict_joint_positive=gl>0,sign_sha256=sha(out),sign_bytes=out.stat().st_size,elapsed_seconds=time.time()-start)
    (P/'iv265_sign.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:v for k,v in rec.items() if k!='gershgorin_row_numerators'},indent=2),flush=True)
if __name__=='__main__':main()
