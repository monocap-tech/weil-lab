"""IV265 full odd explicit residual, variational increment, far and mixed bounds.
Conditional on inherited IEEE/BLAS/longdouble and analytic IV256/262/263 bounds.
No inverse center solve or final sign in this script.
"""
import os, math, json, time
from pathlib import Path
from fractions import Fraction as F
os.environ['OPENBLAS_NUM_THREADS']='4';os.environ['OMP_NUM_THREADS']='4'
import numpy as np
import iv254_intermediate as c
from iv265_plan import sha,gitsha
P=Path(__file__).resolve().parent
S=c.S; J=28672;L=8*J;end=2*L;K=1536;n=14080;p=512;nf=(L-512)//2;no=(end-512)//2;N=256;a=32
EPS=2.**-52; tiny=2.**-450
# Conservative outward guards for positive arithmetic and reductions (<=2^23 terms).
def up(x):return np.nextafter(np.asarray(x)*(1+2.**-40)+tiny,np.inf)
def su(x,axis=None):
    assert np.all(x>=0)
    return up(np.sum(x,axis=axis)*(1+2.**-28))
def norm(x):return float(up(np.sqrt(su(np.abs(x)**2))))
def mm(A,Ar,B,Br):
    # Standard dot-product model; radius product itself uses nonnegative sums.
    assert A.shape==Ar.shape and B.shape==Br.shape and A.shape[1]==B.shape[0] and A.shape[1]<=2**20
    C=A@B; absA=np.abs(A);absB=np.abs(B)
    g=(4*A.shape[1]+32)*EPS
    R=up((absA@Br+Ar@absB+Ar@Br+g*(absA@absB))*(1+2*g))
    return C,R
def add(A,Ar,B,Br):return A+B,up(Ar+Br+8*EPS*(np.abs(A)+np.abs(B)))
def mul(A,Ar,B,Br):return A*B,up(np.abs(A)*Br+Ar*np.abs(B)+Ar*Br+8*EPS*np.abs(A*B))
def powf(x,m):
    x=np.asarray(x); assert np.all(x>=0) and np.all(x<=1)
    P=np.empty((len(x),m));P[:,0]=1
    for k in range(1,m):P[:,k]=P[:,k-1]*x*x
    return P,up(1e-10*np.abs(P))
def fracup(f):
    v=float(f)
    if F.from_float(v)<f:v=math.nextafter(v,math.inf)
    assert F.from_float(v)>=f
    return v

def main():
    start=time.time(); refs={}
    for name,key in [('receiver_inputs','input_sha256'),('scalar','npz_sha256'),('joint_proposal','proposal_sha256'),('action','action_sha256')]:
        r=json.loads((P/f'iv265_{name}.json').read_text()); h=sha(P/f'iv265_{name}.npz');assert h==r[key];refs[name]=h
    assert gitsha(P/'iv254_intermediate.py')=='d2671f69193ef70515546a91fbb95cb6166cd2b7'
    assert np.finfo(np.longdouble).nmant>=63
    z=np.load(P/'iv265_scalar.npz');js=z['js'];A=z['A'];Ar=z['Ar'];b=z['b'];br=z['br'];assert len(js)==no and js[0]==513 and js[p]==1537 and js[n]==J+1 and js[nf]==L+1
    u=np.load(P/'iv265_receiver_inputs.npz');q=u['q'];qr=u['qr'];nn=u['nn'];nr=u['nr'];R=u['R'];Rr=u['Rr'];me=u['me'];ne=u['ne'];ac=q.shape[1];assert q.shape==(N,456) and R.shape==(p,N)
    v=np.load(P/'iv265_joint_proposal.npz');X=v['Xi'].astype(float)/int(v['Q']);assert X.shape==(nf,a) and np.max(np.abs(v['Xi']))<2**52
    v=np.load(P/'iv265_action.npz');act=v['acts'];rad=v['rads'];ae=v['ae'];assert act.shape==(no,a) and rad.shape==act.shape
    aeF=norm(ae);qm=su(np.abs(q)+qr,axis=1);nm=su(np.abs(nn)+nr,axis=1)
    ef=32*ac*ac*2.**-63+(8*ac+32)*EPS
    em=up(ef*qm+me+su(qr,axis=1));en=up(ef*nm+ne+su(nr,axis=1))
    def old(sl):
        j=js[sl];x=2*(np.longdouble(K)/j.astype(np.longdouble))**2-1
        # Longdouble recurrence; conversion and BLAS evaluation charged by ef.
        P0=np.empty((len(j),ac));prev=np.ones(len(j),dtype=np.longdouble);cur=x.copy();P0[:,0]=prev;P0[:,1]=cur
        for k in range(2,ac):prev,cur=cur,2*x*cur-prev;P0[:,k]=cur
        M=P0@q.T;NN=P0@nn.T;v=(A[sl,None]*M-NN)/j[:,None]**2
        er=up(((np.abs(A[sl,None])+Ar[sl,None])*em+Ar[sl,None]*np.abs(M)+en+32*EPS*(np.abs(A[sl,None]*M)+np.abs(NN)))/j[:,None]**2+32*EPS*np.abs(v))
        return v,er
    # Signed tapered prime mixed features. Use actual odd b_j intervals.
    inv=float(c.mid(c.inv))/S;assert max(abs(c.inv[0]-c.mid(c.inv)),abs(c.inv[1]-c.mid(c.inv)))<S//(1<<60)
    x=js[:n]/J;w=(1-x*x)**3;P0,Pr=powf(x,8);FF=np.concatenate((w[:,None]*P0,(w*x*b[:n])[:,None]*P0),axis=1)
    FFr=up(1e-9*(np.abs(FF)+np.concatenate((P0,P0),axis=1)))
    # Exact d_j=.2+log(j/J) interval on late explicit odd nodes.
    dl,du=c.ad(c.I(1,5),c.log(L+1,J));di=[];dirad=[]
    for j in js[nf:].tolist():
        assert F(dl,S)>F(11,5);lo=F(S,du);hi=F(S,dl);v=float((lo+hi)/2);di.append(v);dirad.append(fracup(max(abs(F.from_float(v)-lo),abs(hi-F.from_float(v)))))
        t=j+1;dl+=sum(2*S//(k*t**k) for k in (1,3,5));du+=sum(c.ce(2*S,k*t**k) for k in (1,3,5))+1
    assert 2*S*(L+1)**2<7*(L+1)**7*((L+1)**2-1)
    di=np.array(di);dirad=np.array(dirad)
    C=np.zeros((N,a));Cr=np.zeros_like(C);G=np.zeros((N,N));Gr=np.zeros_like(G);ft=np.zeros((16,N));ftr=np.zeros_like(ft);Y=np.zeros((n,N));Yr=np.zeros_like(Y)
    near2=nearr2=late2=laterr2=0.
    for first,last in [(0,p),(p,n),(n,nf),(nf,no)]:
        for i in range(first,last,2048):
            sl=slice(i,min(i+2048,last));r,rr=(R,Rr) if i==0 else old(sl)
            if i<nf:
                t,tr=mm(r.T,rr.T,X[sl],np.zeros_like(X[sl]));C,Cr=add(C,Cr,t,tr)
            e=r.copy();er=rr.copy();e[:,:a],er[:,:a]=add(r[:,:a],rr[:,:a],-act[sl],rad[sl])
            if i<n:Y[sl]=e;Yr[sl]=er
            if i<nf:near2=float(up(near2+su(e*e)));nearr2=float(up(nearr2+su(er*er)))
            else:
                late2=float(up(late2+su(e*e)));laterr2=float(up(laterr2+su(er*er)));t,tr=mm(e.T,er.T,e,er);G,Gr=add(G,Gr,t,tr)
                j=js[sl];x=J/j;P0,Pr=powf(x,8);dd=di[i-nf:sl.stop-nf];ddr=dirad[i-nf:sl.stop-nf]
                h0=-b[sl]*inv*dd/j;h1=x*inv*dd/j
                H=np.concatenate((h0[:,None]*P0,h1[:,None]*P0),axis=1)
                h0r=abs(inv)/j*(br[sl]*dd+(np.abs(b[sl])+br[sl])*ddr);h1r=abs(inv)*x*ddr/j
                Hr=up(1e-9*(np.abs(H)+np.concatenate((P0,P0),axis=1)/j[:,None])+np.concatenate((h0r[:,None]*P0,h1r[:,None]*P0),axis=1))
                t,tr=mm(H.T,Hr.T,e,er);ft,ftr=add(ft,ftr,t,tr)
        print('residual rows',last,time.time()-start,flush=True)
    # Variational increment in rotated basis, independent action l2 errors charged.
    H,Hr=mm(X.T,np.zeros_like(X.T),act[:nf],rad[:nf]);xn=np.array([norm(X[:,i]) for i in range(a)]);Hr=up(Hr+xn[:,None]*ae[None,:]);C0=np.zeros((N,N));C0r=np.zeros_like(C0);C0[:,:a]=C;C0r[:,:a]=Cr
    D,Dr=add(-C0,C0r,-C0.T,C0r.T);D[:a,:a],Dr[:a,:a]=add(D[:a,:a],Dr[:a,:a],H,Hr)
    nearF=float(up(math.sqrt(near2)+math.sqrt(nearr2)+aeF));lateF=float(up(math.sqrt(late2)+math.sqrt(laterr2)+aeF))
    # Far tail: preserve signed cancellation of constant moments, bound remaining variation.
    P0,Pr=powf(js[:nf]/L,32);mu,mur=mm(P0.T,Pr.T,X,np.zeros_like(X));AX,AXr=mul(A[:nf,None],Ar[:nf,None],X,np.zeros_like(X));nu,nur=mm(P0.T,Pr.T,AX,AXr)
    sg=(-1.)**np.arange(ac);m0,m0r=mm(sg[None,:],np.zeros((1,ac)),q.T,qr.T);n0,n0r=mm(sg[None,:],np.zeros((1,ac)),nn.T,nr.T)
    def far(coeff,cr,z,zr,m,mr,err,ax,axr):
        z=z.ravel().copy();zr=up(zr.ravel()+err);z[:a],zr[:a]=add(z[:a],zr[:a],-m[0],mr[0]);pp=.25**np.arange(1,32)
        rr=up(2*(K/end)**2*su((np.abs(coeff)+cr)*np.arange(ac)**2,axis=1))
        rr[:a]=up(rr[:a]+su(pp[:,None]*(np.abs(m[1:])+mr[1:]),axis=0)+4.**-32/(1-.25)*su(np.abs(ax)+axr,axis=0))
        return norm(up(np.abs(z)+zr+rr))
    M=far(q,qr,m0,m0r,mu,mur,me,X,np.zeros_like(X));NN=far(nn,nr,n0,n0r,nu,nur,ne,AX,AXr)
    sp=lambda k:fracup(F(1,end**k)+F(1,2*(k-1)*end**(k-1)));b2=float(up(4*sp(2)+1200/end**2));farF=float(up(M*(2*math.sqrt(sp(2))+(8/3)*math.sqrt(b2))+(NN+M)*math.sqrt(sp(4))))
    # Mixed center and total uncertainty per IV262/263 lifted inverse proof.
    yc,ycr=mm(FF,FFr,ft,ftr);y,yr=add(Y,Yr,yc,ycr)
    w0=float(up(norm(w)+1e-9*math.sqrt(n)));w1=float(up(norm(w*js[:n]*b[:n])+1e-8*J*math.sqrt(n)))
    hs=float(up((4/3)/(1-1/256)*(w0*math.sqrt(b2/2.9)+w1*math.sqrt(sp(4)/2.9))))
    geom=float(up((26*4/3)*math.sqrt(n*(1/L**2+1/(2*L)))*(1/64)**8/(1-1/64)/2.2*lateF))
    ye=float(up(norm(yr)+41*aeF+40*nearF+geom+hs*farF/math.sqrt(2.9)))
    out=P/'iv265_residual.npz';np.savez(out,D=D,Dr=Dr,G=G,Gr=Gr,y=y,yr=yr)
    rec=dict(scope='all 256 odd residuals; full explicit and analytic far bounds; variational increment and mixed center; inverse and sign not executed',source_git_blob=gitsha(Path(__file__)),sources=refs,nearF=nearF,lateF=lateF,aeF=aeF,far_M=M,far_N=NN,farF=farF,mixed_error=ye,mixed_center_norm=norm(y),mixed_entry_radius_norm=norm(yr),far_mixed=hs*farF/math.sqrt(2.9),geom=geom,delta_center_min_diagnostic=float(np.linalg.eigvalsh((D+D.T)/2)[0]),residual_sha256=sha(out),residual_bytes=out.stat().st_size,elapsed_seconds=time.time()-start)
    (P/'iv265_residual.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec,indent=2),flush=True)
if __name__=='__main__':main()
