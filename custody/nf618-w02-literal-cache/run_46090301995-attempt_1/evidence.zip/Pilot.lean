import WeilDefect.Generated.NF618W02Segmented.Cache
namespace WeilDefect
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem nf618SegPilotRow0 : neutralNF617MomentRowCheck nf618SegPilotCache (21/352) neutralNF616Q nf618SegPilotTable.rows 0=true := by
  decide +kernel

theorem nf618SegPilotRow1 : neutralNF617MomentRowCheck nf618SegPilotCache (21/352) neutralNF616Q nf618SegPilotTable.rows 1=true := by
  decide +kernel

theorem nf618SegPilotRow2 : neutralNF617MomentRowCheck nf618SegPilotCache (21/352) neutralNF616Q nf618SegPilotTable.rows 2=true := by
  decide +kernel

theorem nf618SegPilotRow3 : neutralNF617MomentRowCheck nf618SegPilotCache (21/352) neutralNF616Q nf618SegPilotTable.rows 3=true := by
  decide +kernel

theorem nf618SegPilotRowsCheck : (List.range nf618SegPilotTable.rows.size).all (neutralNF617MomentRowCheck nf618SegPilotCache nf618SegPilotTable.key.lower neutralNF616Q nf618SegPilotTable.rows)=true := by
  rw [nf618SegPilotSize,nf618SegPilotLower]
  apply List.all_eq_true.mpr
  intro j hj
  have hj' := List.mem_range.mp hj
  have h : j=0 ∨ j=1 ∨ j=2 ∨ j=3 := by omega
  rcases h with rfl | rfl | rfl | rfl
  · exact nf618SegPilotRow0
  · exact nf618SegPilotRow1
  · exact nf618SegPilotRow2
  · exact nf618SegPilotRow3
theorem nf618SegPilotSound : neutralNF690TableSound nf618SegPilotTable := by
  apply neutralNF690TableSound_of_semantic_cache nf618SegPilotCache nf618SegPilotTable nf618SegCacheSound
  · rw [nf618SegPilotLower]
    norm_num
  · exact neutralNF616Q_pos
  · intro n hn
    exact List.all_eq_true.mp nf618SegPilotRowsCheck n (List.mem_range.mpr hn)
#print axioms nf618SegPilotRow0
#print axioms nf618SegPilotRow1
#print axioms nf618SegPilotRow2
#print axioms nf618SegPilotRow3
#print axioms nf618SegPilotRowsCheck
#print axioms nf618SegPilotSound

end WeilDefect
