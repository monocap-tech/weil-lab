import WeilDefect.Generated.NF618W02Segmented.Cache
namespace WeilDefect
set_option maxRecDepth 100000
set_option maxHeartbeats 0

#eval (List.range 4).map (neutralNF617MomentRowCheck nf618SegPilotCache (21/352) neutralNF616Q nf618SegPilotTable.rows)

end WeilDefect
