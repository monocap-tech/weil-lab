import zipfile,hashlib,re,json,collections,sys,pathlib
p=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/iv234-am-integrated-terminal-replay.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(p.read_bytes())=='775df6e9ff3ffad67f7fe9aa1ed0d7acb1d86643daf39e131d44f7fe82975ebe'
z=zipfile.ZipFile(p); assert z.testzip() is None
ns=z.namelist();assert len(ns)==len(set(ns)); sm=json.loads(z.read('replay/source-manifest.json')); assert len(sm)==731
# Reconstruct ONLY the omitted generated RowBank source from the pinned sector generator's assemble branch, not a new proof.
ns0='WeilDefect.Arithmetic.IV160Bank.'
header='namespace WeilDefect\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n'
sectors=[(32,128)]+[(128*k,128*(k+1)) for k in range(1,8)]
groups=[(0,32,'neutralIV165Prefix')]+[(lo,hi,f'neutralIV165RowSector{k:02}') for k,(lo,hi) in enumerate(sectors)]
lines=[];indent='  '
for lo,hi,name in groups[:-1]:
 lines += [indent+f'by_cases hi_{hi} : i < {hi}',indent+f'· exact {name} i (by omega) (by omega)',indent+'·'];indent+='  '
lo,hi,name=groups[-1];lines.append(indent+f'exact {name} i (by omega) (by omega)')
body='theorem neutralIV165Prefix (i : ℕ) (_hl : 0 ≤ i) (hu : i < 32) : neutralIV159RowBlock i = true := neutralIV160RowPrefix0032 i hu\n\n'
body+='theorem neutralIV160RowBank (i : ℕ) (hi : i < 1024) : neutralIV159RowBlock i = true := by\n'+'\n'.join(lines)
rowbank=(''.join('import '+i+'\n' for i in [ns0+'RowPrefix0032']+[ns0+f'RowSector{k:02}' for k in range(8)])+header+body+'\n#print axioms neutralIV160RowBank\nend WeilDefect\n').encode()
byname={pathlib.PurePosixPath(n).name:n for n in ns if n.endswith('.lean')};assert len(byname)==730
assert set(pathlib.PurePosixPath(n).name for n in sm)-set(byname)=={'RowBank.lean'}
source={}; leaves=collections.defaultdict(list)
for path,digest in sm.items():
 name=pathlib.PurePosixPath(path).name;b=rowbank if name=='RowBank.lean' else z.read(byname[name]); assert sha(b)==digest,(name,sha(b),digest);source[name]=b
 s=b.decode();assert not re.search(r'\b(?:sorry|admit|sorryAx|native_decide|axiom)\b',s),name
 for kind,i in re.findall(r'^theorem neutralIV159(Row|Sym)_(\d{4})\b',s,re.M):leaves[kind].append(int(i))
assert sorted(leaves['Row'])==list(range(1024));assert sorted(leaves['Sym'])==list(range(128))
allow={'propext','Classical.choice','Quot.sound'}
seen=[]; hashes=0; modules=[]
def check(path,digest):
 global hashes
 assert sha(z.read(path))==digest,path;hashes+=1
def receipt(log,n,leaf=False):
 pat=r"'WeilDefect\."+re.escape(n)+r"' (?:does not depend on any axioms|depends on axioms: \[([^\]]*)\])"
 hits=re.findall(pat,log);assert len(hits)==1,(n,len(hits)); assert set(hits[0].replace(' ','').split(','))-{''}<=allow,(n,hits)
 if leaf:assert hits[0]=='',(n,hits)
def noerr(log):assert not re.search(r'(?m)^.*error(?:\(lean[^)]*\))?:',log)
for path in [x for x in ns if x.endswith('/manifest.json')]:
 dat=json.loads(z.read(path)); rec=dat['records'] if isinstance(dat,dict) else dat;base=path.rsplit('/',1)[0]
 for r in rec:
  m=r['module'].split('.')[-1];assert r['pass'];modules.append(m);check(base+'/'+m+'.lean',r['source_sha256']);check(base+'/'+m+'.log',r['log_sha256']);log=z.read(base+'/'+m+'.log').decode();noerr(log)
  if 'objects' in r:
   for o,d in r['objects'].items():check(base+'/'+o,d)
  else:check(base+'/'+m+'.olean',r['olean_sha256'])
  for name in r.get('names',r.get('expected',[])):
   receipt(log,name, bool(re.fullmatch(r'neutralIV159(?:Row|Sym)_\d{4}',name)));seen.append(name)
assert len(modules)==len(set(modules))==730;assert len(seen)==len(set(seen))
terminal={
 'IV160Bank_RowBank':('RowBank',['neutralIV160RowBank']),
 'ActualZetaIV170AMPhysicalTerminal':('ActualZetaIV170AMPhysicalTerminal',['neutralIV170FullRows','neutralIV170PhysicalTerminal']),
 'ActualZetaIV160AMTerminalReceiver':('ActualZetaIV160AMTerminalReceiver',['neutralIV160Full_rows','neutralIV160Original_bound']),
 'ActualZetaIV215AMOriginalTerminal':('ActualZetaIV215AMOriginalTerminal',['neutralIV215OriginalTerminal'])}
for logstem,(obj,names) in terminal.items():
 log=z.read('replay/'+logstem+'.log').decode();noerr(log); assert 'Build completed successfully' in log;assert len(z.read('replay/'+obj+'.olean'))>0
 for name in names:receipt(log,name)
assert 'Fresh physical and original arithmetic terminal replay PASS' in z.read('full-replay.log').decode()
result={'archive_sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'zip_members':len(ns),'manifest_hashes_verified':hashes,'bank_modules_archived':len(modules),'generated_source_hashes_verified':len(sm),'row_blocks':len(leaves['Row']),'symmetry_blocks':len(leaves['Sym']),'unique_bank_receipts':len(seen),'terminal_receipts':sum(len(n) for _,n in terminal.values()),'rowbank_source_reconstructed_sha256':sha(rowbank),'exact_audit_sha256':sha(z.read('exact-audit.json')),'terminal_source_recorded_sha256':z.read('replay/terminal-source.sha256').decode().strip(),'terminal_log_sha256':sha(z.read('replay/ActualZetaIV215AMOriginalTerminal.log')),'terminal_olean_sha256':sha(z.read('replay/ActualZetaIV215AMOriginalTerminal.olean'))}
print(json.dumps(result,indent=2));pathlib.Path('/mnt/data/W02-AM-01-terminal-audit.json').write_text(json.dumps(result,indent=2)+'\n')
