import WeilDefect.Generated.NF618W02Segmented.Root
namespace WeilDefect
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem nf618B25Unit : NF591Rect.one.Contains (Complex.exp ((0:ℂ)*(11/10))) := by
  norm_num [NF591Rect.one,NF591Rect.Contains,NF591Ball.Contains]

end WeilDefect
