import WeilDefect.Arithmetic.ActualZetaOriginalPhysicalMomentTableSound
import WeilDefect.Arithmetic.ActualZetaOriginalPhysicalShapedBank

namespace WeilDefect
noncomputable section

/-! Semantic cache contract. Unlike NF648, no equality to a particular
exponential evaluator is required. The actual frequency and two actual
exponential endpoints must be enclosed, and every original moment row
must pass the unchanged rational residual checker. -/

def NF617MomentCache.SemanticSound (c : NF617MomentCache)
    (k : NF616Frequency) : Prop :=
  c.z.Contains k.value ∧
  c.pos.Contains (Complex.exp (k.value * ((11/10:ℝ):ℂ))) ∧
  c.neg.Contains (Complex.exp (k.value * ((-(11/10:ℝ)):ℂ)))

theorem neutralNF618SemanticCache_boundary
    (c : NF617MomentCache) (k : NF616Frequency)
    (hs : c.SemanticSound k) (Q n : ℕ) (hQ : 0 < Q) :
    (c.boundary Q n).Contains
      (neutralNF614Boundary (-(11/10:ℝ)) (11/10:ℝ) k.value n) := by
  have hb := NF591Rect.contains_mulQ
    (NF591Rect.contains_realQ ((11/10:ℚ)^n) Q hQ) hs.2.1 Q hQ
  have ha := NF591Rect.contains_mulQ
    (NF591Rect.contains_realQ ((-11/10:ℚ)^n) Q hQ) hs.2.2 Q hQ
  unfold NF617MomentCache.boundary neutralNF614Boundary
  convert NF591Rect.contains_add hb (NF591Rect.contains_neg ha) using 1 <;>
    push_cast <;> ring

theorem neutralNF618MomentRows_of_semantic_cache
    (c : NF617MomentCache) (k : NF616Frequency)
    (hs : c.SemanticSound k) (hd : 0 < k.lower)
    (Q : ℕ) (hQ : 0 < Q) (rows : Array NF617MomentRow)
    (hc : ∀ n < rows.size,
      neutralNF617MomentRowCheck c k.lower Q rows n = true)
    (n : ℕ) (hn : n < rows.size) :
    ‖neutralNF606ExpMoment (-(11/10:ℝ)) (11/10:ℝ) k.value n -
      (neutralNF617MomentRead rows n).value‖ ≤
      (neutralNF617MomentRead rows n).rad := by
  have hd' : (0:ℝ) < (k.lower:ℝ) := by exact_mod_cast hd
  have hz := k.lower_sound
  have hb (m : ℕ) := neutralNF618SemanticCache_boundary c k hs Q m hQ
  induction n with
  | zero =>
    let q := neutralNF617MomentRead rows 0
    have h0 := hc 0 hn
    simp only [neutralNF617MomentRowCheck,Bool.and_eq_true] at h0
    have hcheck := h0.2
    change neutralNF615RectBelow
      (neutralNF615BaseResidualRect (c.boundary Q 0) c.z (q.rect Q) Q)
      (k.lower*q.rad) = true at hcheck
    have hres := NF591Rect.contains_add (hb 0)
      (NF591Rect.contains_neg (NF591Rect.contains_mulQ hs.1 (q.rect_sound Q hQ) Q hQ))
    have hr := (show
      (neutralNF615BaseResidualRect (c.boundary Q 0) c.z (q.rect Q) Q).Contains
        (neutralNF614Boundary (-(11/10:ℝ)) (11/10:ℝ) k.value 0 - k.value*q.value) by
      simpa only [neutralNF615BaseResidualRect,sub_eq_add_neg] using hres)
    have hbound := neutralNF615RectBelow_sound _ _ (k.lower*q.rad) hr hcheck
    apply neutralNF614Moment_zero_enclosure _ _ _ q.value (k.lower:ℝ) (q.rad:ℝ) hd' hz
    simpa only [Rat.cast_mul] using hbound
  | succ n ih =>
    let q := neutralNF617MomentRead rows (n+1)
    let prev := neutralNF617MomentRead rows n
    have h0 := hc (n+1) hn
    simp only [neutralNF617MomentRowCheck,Bool.and_eq_true] at h0
    have hcheck := h0.2
    let S : ℚ := k.lower*q.rad-(n+1:ℚ)*prev.rad
    change neutralNF615RectBelow
      (neutralNF615ResidualRect (c.boundary Q (n+1)) c.z (prev.rect Q) (q.rect Q) Q n) S = true at hcheck
    have hres := neutralNF615ResidualRect_sound _ _ _ _ _ _ _ _
      Q n hQ (hb (n+1)) hs.1 (prev.rect_sound Q hQ) (q.rect_sound Q hQ)
    have hbound := neutralNF615RectBelow_sound _ _ S hres hcheck
    exact neutralNF614Moment_succ_enclosure _ _ _ prev.value q.value n
      (k.lower:ℝ) (prev.rad:ℝ) (q.rad:ℝ) (S:ℝ) hd' hz
      (ih (by omega)) hbound (by dsimp [S]; push_cast; linarith)

theorem neutralNF690TableSound_of_semantic_cache
    (c : NF617MomentCache) (t : NF624KeyTable)
    (hs : c.SemanticSound t.key) (hd : 0 < t.key.lower)
    (Q : ℕ) (hQ : 0 < Q)
    (hc : ∀ n < t.rows.size,
      neutralNF617MomentRowCheck c t.key.lower Q t.rows n = true) :
    neutralNF690TableSound t := by
  intro n hn
  exact neutralNF618MomentRows_of_semantic_cache c t.key hs hd Q hQ t.rows hc n hn

end
end WeilDefect
